-- Assignment Session 7 

--1 
USE StoreDB
CREATE NONCLUSTERED INDEX idx_customers_email
ON sales.customers (email);

---------------------------------------------------------
--2
CREATE NONCLUSTERED INDEX idx_category_brand
ON production.products (category_id, brand_id);

---------------------------------------------------------
--3
CREATE NONCLUSTERED INDEX idx_orders_orderdate
ON sales.orders (order_date)
INCLUDE (customer_id, store_id, order_status);

---------------------------------------------------------
--4

CREATE TABLE sales.customer_log (
    log_id INT IDENTITY(1,1) PRIMARY KEY,
    customer_id INT,
    action VARCHAR(50),
    log_date DATETIME DEFAULT GETDATE()
);
GO
CREATE TRIGGER trg_customer_welcome
ON sales.customers
AFTER INSERT
AS
BEGIN
   INSERT INTO sales.customer_log (customer_id, message)
   SELECT i.customer_id, 'Welcome new customer'
   FROM inserted i;
END;
----------------------------------------------------------
--5 
CREATE TABLE production.price_history (
    history_id INT IDENTITY(1,1) PRIMARY KEY,
    product_id INT,
    old_price DECIMAL(10,2),
    new_price DECIMAL(10,2),
    change_date DATETIME DEFAULT GETDATE(),
    changed_by VARCHAR(100)
);
GO
CREATE TRIGGER trg_price_change
ON production.products
AFTER UPDATE
AS
BEGIN
    INSERT INTO production.price_history (product_id, old_price, new_price)
    SELECT
        i.product_id, d.list_price AS old_price, i.list_price AS new_price
    FROM inserted i
    INNER JOIN deleted d ON i.product_id = d.product_id
    WHERE ISNULL(i.list_price, 0) <> ISNULL(d.list_price, 0);
END;
------------------------------------------------------------------
--6 
CREATE TRIGGER trg_prevent_delete_category
ON production.categories
INSTEAD OF DELETE
AS 
BEGIN
     IF EXISTS ( 
            SELECT 1 
            FROM production.products p
            INNER JOIN deleted d ON p.category_id = d.category_id
)
BEGIN
       RAISERROR ('Cannot delete category because it has associated products.', 16, 1);
       ROLLBACK TRANSACTION;
       RETURN;
END

  DELETE FROM production.categories
  WHERE category_id IN (SELECT category_id FROM deleted);
END;
----------------------------------------------------------------
--7
CREATE TRIGGER trg_reduce_stock_on_insert
ON sales.order_items
AFTER INSERT 
AS 
BEGIN
  UPDATE s 
  SET s.quantity = s.quantity - i.quantity
  FROM production.stocks s 
  INNER jOIN inserted i ON s.product_id = i.product_id;
END;
----------------------------------------------------------------
--8
CREATE TABLE sales.order_audit (
    audit_id INT IDENTITY(1,1) PRIMARY KEY,
    order_id INT,
    customer_id INT,
    store_id INT,
    staff_id INT,
    order_date DATE,
    audit_timestamp DATETIME DEFAULT GETDATE()
);
GO
CREATE TRIGGER trg_log_new_orders
ON sales.orders
AFTER INSERT
AS
BEGIN 
     INSERT INTO sales.order_audit (order_id, customer_id, order_date, store_id, order_status)
     SELECT order_id, customer_id, order_date, store_id, order_status
     FROM inserted;
END;
